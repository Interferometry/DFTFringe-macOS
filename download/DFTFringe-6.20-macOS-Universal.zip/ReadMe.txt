  ____  _____ _____ _____     _
 |    \|   __|_   _|   __|___|_|___ ___ ___
 |  |  |   __| | | |   __|  _| |   | . | -_|
 |____/|__|    |_| |__|  |_| |_|_|_|_  |___|
                                   |___|

DFTFringe 6.2 For macOS

- Universal build (Apple Silicon & Intel).
- Gatekeeper friendly, application has been signed and notarised.
- Requires macOS Ventura, or later.

INSTALLATION:

- Unzip the file and drag the DFTFringe app into the Applications folder.
- To uninstall, drag DFTFringe from the applications folder to Bin/Trash.

FEEDBACK:

Feedback is welcome, MacOS specific DFTFringe issues can be reported here:

    GitHub : https://github.com/Interferometry/DFTFringe-macOS

Please post any issues with the DFTFringe to:

    GitHub : https://github.com/githubdoe/DFTFringe

Discussion group about interferometry, including DFTFringe here:

 Groups.io : https://groups.io/g/Interferometry
